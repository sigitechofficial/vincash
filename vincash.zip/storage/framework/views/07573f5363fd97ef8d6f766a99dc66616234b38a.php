<?php $__env->startSection('content'); ?>
<style>
    .spacing{
        padding-left:15%;
        padding-right:15%;
        
    }
</style>
<a id="get-offer-btn" class="text-center">Get Offer Here</a>

<div class="banner d-flex align-items-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12 col-12">
                <div class="card" style="margin-top:-2rem;">
                   
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                    <div class="card-body spacing">
                        <h2 class="text-center mb-4 mt-4 font-36">Dealer Login</h2>
                         <?php if(session()->has('msg')): ?>
                             <div class="alert alert-danger"><?php echo e(session()->get('msg')); ?></div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="smith@gmail.com">
                             <?php if($errors->has('email')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('email')); ?></div>
                                    <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="text" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Enter Password">
                             <?php if($errors->has('password')): ?>
                                        <div class="error text-danger"><?php echo e($errors->first('password')); ?></div>
                                    <?php endif; ?>
                        </div>
                        <div class="mt-3">
                            <div class="col-lg-12 col-md-12 col-12">
                                <button class="btn btn-primary btn-lg btn-block mt-5 mb-3" type="submit">Login</button>
                            </div>
                        </div>
                      
                    </div>
                    </form>
                </div>
            </div>
           
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vincashc/public_html/resources/views/login.blade.php ENDPATH**/ ?>