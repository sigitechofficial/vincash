<?php $__env->startSection('content'); ?>

<div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h2>Messages</h2>
                </div>            
                <div class="col-md-6 col-sm-12 text-right">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item">Table</li>
                        <li class="breadcrumb-item active">Messages DataTable</li>
                    </ul>
                  
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="card">
                <div class="header">
                    <ul class="header-dropdown dropdown dropdown-animated scale-left">
                        <li> <a href="javascript:void(0);" data-toggle="cardloading" data-loading-effect="pulse"><i class="icon-refresh"></i></a></li>
                    </ul>
                </div>
                <div class="body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover js-basic-example dataTable table-custom shadow">
                            <thead>
                                <tr>
                                    <th>Serial No</th>
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Zip</th>
                                    <th>Message</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                       
                            <tbody>
                              <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($key= $key+1); ?></td>
                                  <td><?php echo e($message->full_name); ?></td>
                                  <td><?php echo e($message->email); ?></td>
                                  <td><?php echo e($message->phone); ?></td>
                                  <td><?php echo e($message->zip); ?></td>
                                  <td><?php echo e($message->message); ?></td>
                                  <td><a class="btn btn-secondary text-white"  href="mailto:<?php echo e($message->email); ?>"><i class="fa fa-paper-plane" aria-hidden="true"></i> &nbsp; Send Email</a></td>
                                  <!--<td><a class="btn btn-danger btn-sm" href="<?php echo e(route('delete_message',['id'=>$message->id])); ?>">Delete</a></td>-->
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vincashc/public_html/resources/views/admin/messages.blade.php ENDPATH**/ ?>