<?php $__env->startSection('content'); ?>

<div style="background-color:#F4F5FA; padding-top:150px;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 text-center">
                <h5 class="font-30  weight-500 color-blue mb-4">We have found the following vehicles that match the given VIN:</h5>
                <h6 class="mb-4 text-muted">.</h6>
            </div>
        </div>
    </div>
    
   <div class="container">
    <h6 class="mb-4">Please select the correct vehicle:</h6>
    <div class="row mb-3">
        <?php $count = 1; ?>
        <?php $__currentLoopData = $vec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-6 col-md-6 col-12">
            <div class="damage_history">
                <input type="radio" id="control_0<?php echo e($count); ?>" name="select">
                <label class="text-left" for="control_0<?php echo e($count); ?>">
                    <p>Vehicle Year: <?php echo e($vehicle->year); ?> </p>
                    <p>Vehicle Model: <?php echo e($vehicle->model); ?> </p>
                    <p>Vehicle Make: <?php echo e($vehicle->make); ?> </p>
                </label>
            </div>
        </div>
        <?php $count++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row mt-5 pb-5 justify-content-around">
        <div class="col-lg-4 col-md-4 col-12">
            <a class="btn btn-primary btn-lg btn-block" href="<?php echo e(route('veh_info', ['vehicle' => $vehicle->id])); ?>">Submit your Response</a>
        </div>
    </div>
</div>



</div>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vincashc/public_html/resources/views/veh_multi.blade.php ENDPATH**/ ?>