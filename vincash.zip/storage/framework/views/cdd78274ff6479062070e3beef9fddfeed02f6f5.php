<!doctype html>
<html lang="en">

<head>
<title>Forgot Password Admin</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta name="description" content="Vincash Admin Dashboard">
<meta name="author" content="vincash, www.vincash.co">
<link rel="icon" href="<?php echo e(asset('public/assets/images/logo.png')); ?>" type="image/x-icon">

<!-- VENDOR CSS -->
<link rel="stylesheet" href="<?php echo e(asset('public/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/vendor/font-awesome/css/font-awesome.min.css')); ?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<!-- MAIN CSS -->
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/color_skins.css')); ?>">
</head>


<body class="theme-orange">
    <!-- WRAPPER -->
    <div id="wrapper" class="auth-main">
        <div class="container">
            
            <div class="row clearfix">
                <div class="col-12">
                    <nav class="navbar navbar-expand-lg">
                       
                    </nav>                    
                </div>
                <div class="col-lg-8">
                    <div class="auth_detail">
                        <img class="img-fluid" src="<?php echo e(asset('public/assets/images/logo/VinCash_original.png')); ?>" alt="logo" >
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="card">
                        <div class="header">
                            <p class="lead">Recover my password</p>
                        </div>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger mx-3" role="alert">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($error); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                         <?php endif; ?>
                        <div class="body">
                            <p>Please enter your email address below to receive instructions for resetting password.</p>
                            <form method="POST" class="form-auth-small" action="<?php echo e(route('forgot_password_post')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">                                    
                                    <input type="email" class="form-control" name="email" id="signup-password" placeholder="email">
                                </div>
                                <button type="submit" class="btn btn-primary btn-lg btn-block">Send Password Reset link</button>
                                <div class="bottom">
                                    <span class="helper-text">Know your password? <a href="<?php echo e(route('admin.login')); ?>">Login</a></span>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END WRAPPER -->
  
<script src="assets/bundles/libscripts.bundle.js"></script>    
<script src="assets/bundles/vendorscripts.bundle.js"></script>

<script src="assets/bundles/mainscripts.bundle.js"></script>
  <script>
        <?php if(Session::has('message')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
                toastr.message("<?php echo e(session('message')); ?>");
        <?php endif; ?>
      
        <?php if(Session::has('error')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
                toastr.error("<?php echo session('error'); ?>");
        <?php endif; ?>
      
        <?php if(Session::has('info')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
                toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>
      
        // <?php if(Session::has('warning')): ?>
        // toastr.options =
        // {
        //     "closeButton" : true,
        //     "progressBar" : true
        // }
        //         toastr.warning("<?php echo e(session('warning')); ?>");
        // <?php endif; ?>

        <?php if(Session::has('warning')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-bottom-right"
        }
                toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
        
    </script> 
</body>
</html>
<?php /**PATH /home/vincashc/public_html/resources/views/admin/forgot_password.blade.php ENDPATH**/ ?>