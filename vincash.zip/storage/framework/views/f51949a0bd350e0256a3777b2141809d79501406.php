<?php $__env->startSection('content'); ?>

<div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h2>Page Blank</h2>
                </div>            
                <div class="col-md-6 col-sm-12 text-right">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container-fluid">           
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="card planned_task">
                        <div class="header">
                            <h1>FAQ's</h1>
                        </div>
                        <form method="POST">
                            <?php echo csrf_field(); ?>
                        <div class="body">
                            <div class="form-group">
                                <label>First FAQ</label>
                                <input name="question" type="text" class="form-control mb-2" required placeholder="Question...">
                                <textarea name="answer" type="text" class="form-control" required placeholder=""></textarea>
                            </div> 
                            <button class="btn btn-info float-right mb-2">Submit</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-12">
            <div class="card">
                <div class="header">
                    <ul class="header-dropdown dropdown dropdown-animated scale-left">
                        <li> <a href="javascript:void(0);" data-toggle="cardloading" data-loading-effect="pulse"><i class="icon-refresh"></i></a></li>
                    </ul>
                </div>
                <div class="body">
                    <div class="table-responsive">
                         <h4>All FAQ's</h4>
                        <table class="table table-bordered table-hover js-basic-example dataTable table-custom">
                            <thead>
                                <tr>
                                    <th>Serial No</th>
                                    <th>Question</th>
                                    <th>Answer</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($key=$key+1); ?></td>
                                  <td><?php echo e(Str::limit($faq->question)); ?></td>
                                  <td style="white-space:normal;" ><?php echo e($faq->answer); ?></td>
                                  <td><a href="<?php echo e(route('delete_faq',['id'=>$faq->id])); ?>" class="btn btn-danger btn-sm text-white">Delete</a></td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vincashc/public_html/resources/views/admin/faq.blade.php ENDPATH**/ ?>