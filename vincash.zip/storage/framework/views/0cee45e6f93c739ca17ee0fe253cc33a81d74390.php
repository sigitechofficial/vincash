<?php $__env->startSection('content'); ?>

<div id="main-content">
    <div class="block-header">
        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h2>Buy Vehicles Datatable</h2>
            </div>            
            <div class="col-md-6 col-sm-12 text-right">
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i class="icon-home"></i></a></li>
                    <li class="breadcrumb-item">Table</li>
                    <li class="breadcrumb-item active">Buy Vehicles DataTable</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="header">
                
                <ul class="header-dropdown dropdown dropdown-animated scale-left">
                    <li> <a href="javascript:void(0);" data-toggle="cardloading" data-loading-effect="pulse"><i class="icon-refresh"></i></a></li>
                </ul>
            </div>
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover js-basic-example dataTable table-custom">
                        <thead>
                            <tr>
                                <th>Serial No</th>
                                <th>Vec ID</th>
                                <th>Vin Number</th>
                                <th>Vehicle Type</th>
                                <th>Vehicle Make</th>
                                <th>Model</th>
                                <th>Year</th>
                                <th>KMs</th>
                                <th>City</th>
                                <th>Postal Code</th>
                                <th>Dealer Name</th>
                                <th>Payment Method</th>
                                <!--<th>Read Price</th>-->
                            </tr>
                        </thead>
                    
                        <tbody>
                            <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key = $key + 1); ?></td>
                                <td><?php echo e($card->vehicle_id); ?></td>
                                <td><?php echo e($card->vehicle->vin_number); ?></td>
                                <td><?php echo e($card->vehicle->vehicle_type); ?></td>
                                <td><?php echo e($card->vehicle->make); ?></td>
                                <td><?php echo e($card->vehicle->model); ?></td>
                                <td><?php echo e($card->vehicle->year); ?></td>
                                <td><?php echo e($card->vehicle->km); ?> km</td>
                                <td><?php echo e($card->vehicle->user->city); ?></td>
                                <td><?php echo e($card->vehicle->postal_code); ?></td>
                                <td><span ><?php echo e($card->dealer->first_name); ?> <?php echo e($card->dealer->last_name); ?></span></td>
                                <td><?php echo e($card->payment_method); ?></td>
                                <!--<td><span ><?php echo e($card->amount); ?> $</span></td>-->
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                         
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vincashc/public_html/resources/views/admin/buy_veh.blade.php ENDPATH**/ ?>