<?php $__env->startSection('content'); ?>
<style>
    .btn
{
    border-radius:0px !important;
}
</style>
<div id="main-content">
    <div class="block-header">
        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h2>Dealer Buy Vehicles</h2>
            </div>            
            <div class="col-md-6 col-sm-12 text-right">
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i class="icon-home"></i></a></li>
                    <li class="breadcrumb-item">Table</li>
                    <li class="breadcrumb-item active">Dealer Buy Vehicles</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="header">
                
                <ul class="header-dropdown dropdown dropdown-animated scale-left">
                    <li> <a href="javascript:void(0);" data-toggle="cardloading" data-loading-effect="pulse"><i class="icon-refresh"></i></a></li>
                </ul>
            </div>
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover js-basic-example dataTable table-custom">
                        <thead>
                            <tr>
                               
                                <th>Vehicle ID</th>
                                <th>Vin Number</th>
                                <th>Vehicle Type</th>
                                <th>Year</th>
                                <th>Vehicle Make</th>
                                <th>Model</th>
                                <th>KMs</th>
                                <th>City</th>
                                <th>Postal Code</th>
                                <th>Est. Price</th>
                                <th>Demand Price</th>
                                <th>Payment Method</th>
                              
                               
                            </tr>
                        </thead>
                   
                        <tbody>
                           <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                               <td><?php echo e($vec->vehicle->id); ?></td>
                               <td><?php echo e($vec->vehicle->vin_number); ?></td>
                               <td><?php echo e($vec->vehicle->vehicle_type); ?></td>
                               <td><?php echo e($vec->vehicle->year); ?></td>
                               <td><?php echo e($vec->vehicle->make); ?></td>
                               <td><?php echo e($vec->vehicle->model); ?></td>
                               <td><?php echo e($vec->vehicle->km); ?></td>
                               <td><?php echo e($vec->vehicle->user->city); ?></td>
                               <td><?php echo e($vec->vehicle->postal_code); ?></td>
                               <td><?php echo e($vec->vehicle->est_price); ?></td>
                               <td><?php echo e($vec->vehicle->demand_price); ?></td>
                               <td><?php echo e($vec->payment_method); ?></td>
                              
                           </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>










<script>


 
    
    
    
    var selectAllItems = "#select-all";
    var checkboxItem = ":checkbox";
    
    $(selectAllItems).click(function() {
    if (this.checked) {
        $(checkboxItem).each(function() {
          this.checked = true;
        });
    } else {
        $(checkboxItem).each(function() {
          this.checked = false;
        });
      }
      
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vincashc/public_html/resources/views/admin/dealer_buy_vehicles.blade.php ENDPATH**/ ?>